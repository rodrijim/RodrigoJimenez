package temas.trimestre;

public class Rombo1 {
public static void main(String[] args) {
		
		// TODO scanner
		//TODO comprobacion impar
		
		int alturaRombo = 5;
		
		int alturaPrimerTriangulo = (alturaRombo + 1) / 2;
		
		
		//Triangulo superior
		for (int fila = 1; fila <= alturaPrimerTriangulo; fila++) {
			
			//Espacios
			for (int col = 1; col <= alturaPrimerTriangulo - fila; col++) {
				System.out.print(" ");
			}
			
			//Astertiscos
			for (int col = 1; col < (fila * 2); col++) {
				System.out.print("*");
			}
			
			
			System.out.println();
		}
		
		
		//Triangulo superior
		for (int fila = 1; fila < alturaPrimerTriangulo; fila++) {
			
			//Espacios
			for (int col = 1; col <= fila; col++) {
				System.out.print(" ");
			}
			
			//Astertiscos
			for (int col = 1; col < (alturaPrimerTriangulo - fila) * 2; col++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
