package edu.alonso.tema3.banco;

import edu.alonso.tema3.banco.modelo.Bizum;
import edu.alonso.tema3.banco.modelo.Domicilio;
import edu.alonso.tema3.banco.modelo.OperacionBancaria;
import edu.alonso.tema3.banco.modelo.Persona;
import edu.alonso.tema3.banco.modelo.Transferencia;

public class Init {

	public static void main(String[] args) {

		OperacionBancaria transferencia = new Transferencia(new Persona("Fran", "Perez", 34, "70707070H"),
				new Domicilio("Prueba", 12, "Salamanca", "Salamanca", 30123));
				
		System.out.println(transferencia);
		
		
		OperacionBancaria bizum = new Bizum(new Persona("Juanito", "Lopez", 31, "70707073M"),
				new Domicilio("Prueba2", 12, "Ávila", "Ávila", 30123), 689689689, 653478999);
		
		System.out.println(bizum);

	}

}
